# AS360 AIO POC Enabler
A single click, single VM, All-In-One installer for POCs

## POC walkthrough
The sections below list a POC preperations, as well as the actions needed to initiate the AS360 AIO system and terminate it (while cleaning all the generated artifacts)

Notes:
+ The ASCP and Omnia (ASRA) kits need to be downloaded and put under the **'kit'** folder
	- **Important**: The execution scripts assume the ASCP installation kit file name matches **'ascp-dart-prime-\*.run'** and the ASRA one matches **'appscan360-secinfo\*.run'**
						If this isn't the case, either the file name(s) need(s) to be adjusted, or the execution scripts (under the **'kit'** folder)
+ **The customization file (kit/singular-singular.clusterKit.properties) needs to be adjusted according to the customer's environment:**
	- **The entry "CK_CONFIGURATION_INTERNAL_MSE_SERVER_NAME=''" exists in the file as a remark,	as customer POCs use production like license keys. In case the AIO is used internally in HCL network, the entry should be uncommented and given the value: hclsoftware-uat (inside the single quatation marks)**
	- **The entry "CK_BACKDOOR_INTERNAL_REPLICAS_COUNT_OVERRIDE='1'" exists in the file and should NOT be used in production systems, as it sets the number of (pods) replicas in the services to 1 (to save resources consumption in POCs)**
	- **In case LDAP and SMTP are not needed for the POC, there is no need to manaully update the customization file, the 'engageAS360.sh' script shall ask for the customer DNS domain name and update the file automatically**
	- **Important: The content of the customization file needs to be revised and adjusted as it may change during the regular life cycle of the AS360 product (consult with AS360 team)**
+ In case the AS360 landing page isn't accessible becuase of DNS resolution, the machine used to access the AS360 UI will need to have the following entry in its hosts file:
	- \<AS360-AIO-POC-VM-IP\> \<AS360-AIO-POC-VM-NAME\>.\<CUSTOMER-DNS-DOMAIN-NAME\>

### Preperations
---
The customer needs to do the following preparations before the POC:
+ Prepare A Ubuntu VM with **16/12** CPUs, **64GB/48GB** RAM and **200GB** disk space
	- Note: Up and running cluster (with no scans running) uses 5/3.5 CPUs and 24GB/17.5GB Ram, single scan needs 2-4 CPUs and 16GB-28GB Ram
	- Installed with:
		+ Openssl (usually installed already in Ubuntu)
		+ Docker (https://docs.docker.com/engine/install/ubuntu)
		+ Kubectl (https://kubernetes.io/docs/tasks/tools/install-kubectl-linux/#install-using-native-package-management)
		+ Helm (https://helm.sh/docs/intro/install)
		+ _**Note: In case there is a need to do the installations mentioned above internally, reference scripts can be found in the 'init' folder, be sure to run them as the root user (not via sudo)!**_
	- Having ports **80** and **443** free/available
	- Pre-configured with a dedicated user for the POC
		+ The user should be part of the **docker** group (sudo usermod -aG docker $USER)
		+ The user must have a **"sudo"** ability/permission
	- Have free access to the Internet (no proxy involved)
+ Have another machine that has a browser on it and can view the VM running AS360 mentioned above (for operating the appscan once deployed)
+ **Answer questions on his environment, before the POC, in order to fill the customization file (in case LDAP/SMTP related abilities need to be demonstrated)**

### D.I.Y (Do It Yourself)
---
In case you are feeling lucky and/or want to practice (internally, as you can't access HCL's GitHub from the customer's premises):
+ Enter the VM created for you, **with the designated user**
+ Clone the AIO repo (_git clone https://github01.hclpnp.com/AppScanIL/as360-aio-poc-enabler.git_)
	- Ubuntu comes with git installed already
	- You will be asked to enter your git credentials (user name and **personal access token** (create one if needed at: _**Settings/Developer settings/Personal access tokens**_))
+ Copy the ASCP and ASRA installation kits to the VM (**to the home folder of the designated user**)
	- Download command example from ASCP Nexus server: _curl -kO https://ascp-nexus-ha.appscan.il/repository/raw-hosted/appscan360-k8s-sea-kit/ascp/asop/ascp-dart-prime-v1.2.125-release-asop-1.2.0-2-asop-4-offline-kit.gz.run_
	- If needed, adjust their names or the execution scripts (_see comment above_)
+ Make them executable (_chmod +x *.run_)
+ Copy them into the **'kit'** folder in AIO folder (_cp *.run as360-aio-poc-enabler/kit_)
+ Enter the AIO folder (_cd as360-aio-poc-enabler_)
+ Run the startup script (_**\.\/engageAS360.sh**_) as listed below
	- Be sure to enter the designated DNS domain when asked to
	- Shared storage content (e.g., logs) can be found on the AIO VM in a designated path (**/var/openebs/local**) under the folder starting with "pvc"
+ Enter the appscan UI: https://\<AS360-AIO-POC-VM-NAME\>.\<CUSTOMER-DNS-DOMAIN-NAME\> and do the demo
+ When done, clean after yourself with the shutdown script (_**\.\/disengageAS360.sh**_) as listed below
	- Manual removal (from the home folder of the designated user):
		+ Remove the cloned repo (_rm -r as360-aio-poc-enabler_)
		+ Remove the ASCP and ASRA kits (_rm -r *.run_)

### Engagement:
---
./engageAS360.sh

### Disengagement:
---
./disengageAS360.sh

## Bon Voyage!
