#!/usr/bin/env sh

./appscan360-secinfo*.run -- -c $PWD/singular-singular.clusterKit.properties
