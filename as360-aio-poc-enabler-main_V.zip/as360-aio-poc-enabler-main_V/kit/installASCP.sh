#!/usr/bin/env sh

export MORE='--lines 10000' && ./ascp-dart-prime-*.run --accept -- $PWD
