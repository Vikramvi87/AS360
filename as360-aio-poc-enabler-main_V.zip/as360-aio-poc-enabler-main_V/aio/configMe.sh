#!/usr/bin/env sh

mkdir -p ~/.docker

docker login -u dpr-user -p dpr-pass $(hostname):5443

mkdir -p ~/.kube

docker compose -f aio-compose.yaml exec k0s cat /var/lib/k0s/pki/admin.conf | tee -a ~/.kube/config
