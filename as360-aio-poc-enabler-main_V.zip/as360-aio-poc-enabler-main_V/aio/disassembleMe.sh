#!/usr/bin/env sh

sudo ./doUnPrepMe.sh
