#!/usr/bin/env sh

sudo ./doPrepMe.sh
