#!/usr/bin/env sh

docker compose ls

echo

docker compose -f aio-compose.yaml top
