#!/usr/bin/env sh

# Remove and clean certificate store
rm -f /usr/local/share/ca-certificates/dpr.crt
update-ca-certificates

# Remove generated certificates and credentials
rm -rf /var/auth/dpr /var/ssl/certs /var/ssl/private

# Restart docker daemon to catch the new certificate
systemctl restart docker

# Remove openebs data
rm -rf /var/openebs/local
