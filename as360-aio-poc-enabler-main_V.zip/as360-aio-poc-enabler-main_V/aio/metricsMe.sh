#!/usr/bin/env sh

watch -n 2 kubectl top pod -n hcl-appscan-ascp
