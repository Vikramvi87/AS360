#!/usr/bin/env sh

docker compose -f aio-compose.yaml down -v
