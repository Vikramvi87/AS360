#!/usr/bin/env sh

kubectl get pods -n hcl-appscan-secinfo --watch
