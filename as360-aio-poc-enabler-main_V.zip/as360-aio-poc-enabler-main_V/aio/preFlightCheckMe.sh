#!/usr/bin/env sh

# Check docker
docker run --rm hello-world

# Check kubectl
kubectl version

# Check helm
helm version

# Check openssl
openssl version
