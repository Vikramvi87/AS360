#!/usr/bin/env sh

# Exit on failure
set -e

./preFlightCheckMe.sh

./assembleMe.sh

./setMeUp.sh

echo "Going to sleep for 3.5 minutes while waiting for the system to warm up..."
sleep 210

./configMe.sh

./inspectAIO.sh
