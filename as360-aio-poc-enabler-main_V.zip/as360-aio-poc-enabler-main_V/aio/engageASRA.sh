#!/usr/bin/env sh

# Exit on failure
set -e

cd ../kit

./installASRA.sh

cd ../aio

echo "Going to sleep for 1 minute while waiting for ASRA to warm up..."
sleep 60

./inspectASRA.sh
