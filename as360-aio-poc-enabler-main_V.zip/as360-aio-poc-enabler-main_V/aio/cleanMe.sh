#!/usr/bin/env sh

# List all images
images=$(docker images -aq)

# Check if the list is empty
if [ -z "$images" ]; then
	echo "No Docker images found."
else
	# Remove all images
	docker rmi -f $images
fi

# Remove k8s config
rm -rf ~/.kube

# Remove docker config
rm -rf ~/.docker
