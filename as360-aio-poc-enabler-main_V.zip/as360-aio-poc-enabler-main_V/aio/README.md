# K0S
Main site: https://k0sproject.io

## OpenEBS (CSI)
Main site: https://openebs.io/

URL: https://openebs.github.io/openebs/

Helm chart: https://openebs.github.io/charts/

Github: https://github.com/openebs/charts

LocalPV: https://openebs.io/docs/user-guides/local-storage-user-guide/local-pv-hostpath/hostpath-installation#prerequisites

Main chart values: https://github.com/openebs/openebs/blob/main/charts/values.yaml

LocalHostPV values: https://github.com/openebs/dynamic-localpv-provisioner/blob/develop/deploy/helm/charts/values.yaml

### Setup mounted local/remote host path (update the below K0S service clause and the helm customization clause (localpv-provisioner), and mount the NFS share to **/mnt/openebs-local**, follow the => mark)
```
services:
  k0s:
    container_name: k0s
    image: docker.io/k0sproject/k0s:v1.29.4-k0s.0
    command: sh -c "update-ca-certificates && k0s controller --config=/etc/k0s/config.yaml --enable-worker --no-taints --enable-metrics-scraper"
    hostname: k0s
    privileged: true
    cgroup: host
    volumes:
      - "/sys/fs/cgroup:/sys/fs/cgroup:rw"
      - "/run/udev:/run/udev"
      - "/var/lib/k0s"
      - "/var/openebs/local:/var/openebs/local" => - "/mnt/openebs-local:/mnt/openebs-local"

localpv-provisioner:
   hostpathClass:
      enabled: true
      isDefaultClass: true
      basePath: "" => basePath: /mnt/openebs-local
```
