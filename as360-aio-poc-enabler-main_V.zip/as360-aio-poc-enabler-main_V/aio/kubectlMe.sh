#!/usr/bin/env sh

docker compose -f aio-compose.yaml exec k0s k0s kubectl $*
