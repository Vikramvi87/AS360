#!/usr/bin/env sh

kubectl get pods -A --watch
