#!/usr/bin/env sh

# Exit on failure
set -e

# Variables
DOMAIN=""
PROPERTIES_FILE_PATH="../kit/singular-singular.clusterKit.properties"

# Read user input into DOMAIN
if [ $# -eq 0 ]
then
	read -p 'Please enter the designated Domain name (e.g. "appscan.com"): ' DOMAIN
else
	DOMAIN=$1
fi

# Edit properties file with input domain
sed -i "s/CK_CNI_NETWORK_DOMAIN_SUFFIX.*/CK_CNI_NETWORK_DOMAIN_SUFFIX=\'${DOMAIN}\'/g" $PROPERTIES_FILE_PATH
sed -i "s/CK_INGRESS_INTERNAL_HOST_DOMAIN.*/CK_INGRESS_INTERNAL_HOST_DOMAIN=\'${DOMAIN}\'/g" $PROPERTIES_FILE_PATH
sed -i "s/CK_CONFIGURATION_DISCLOSED_SITE_URL.*/CK_CONFIGURATION_DISCLOSED_SITE_URL=\"https:\/\/\$(hostname).${DOMAIN}\"/g" $PROPERTIES_FILE_PATH
sed -i "s/CK_CONFIGURATION_DISCLOSED_LDAP_DOMAIN=.*/CK_CONFIGURATION_DISCLOSED_LDAP_DOMAIN=\'${DOMAIN}\'/g" $PROPERTIES_FILE_PATH
