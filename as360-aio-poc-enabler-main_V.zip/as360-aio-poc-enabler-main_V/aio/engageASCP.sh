#!/usr/bin/env sh

# Exit on failure
set -e

./parseMe.sh $*

cd ../kit

./installASCP.sh

cd ../aio

echo "Going to sleep for 2.5 minutes while waiting for ASCP to warm up..."
sleep 150

./inspectASCP.sh
