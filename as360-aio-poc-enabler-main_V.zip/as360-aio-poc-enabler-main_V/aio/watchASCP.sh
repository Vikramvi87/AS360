#!/usr/bin/env sh

kubectl get pods -n hcl-appscan-ascp --watch
