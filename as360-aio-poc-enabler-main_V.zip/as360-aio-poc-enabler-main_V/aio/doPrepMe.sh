#!/usr/bin/env sh

# Make cerificates folders
mkdir -p /var/ssl/certs
mkdir -p /var/ssl/private

# Generate self-signed certificate and key
openssl req -x509 -newkey rsa:4096 -keyout /var/ssl/private/dpr.key -out /var/ssl/certs/dpr.crt -sha256 -days 9125 -nodes -subj "/C=ZZ/ST=ACME/L=NoWhere/O=HCL/OU=Appscan/CN=$(hostname)" -addext "subjectAltName=DNS:$(hostname)" 2>/dev/null

# Publish the public key
cp /var/ssl/certs/dpr.crt /usr/local/share/ca-certificates/
update-ca-certificates

# Restart docker daemon to catch the new certificate
systemctl restart docker

# Create credentials for the DPR
mkdir -p /var/auth/dpr
docker run --rm --entrypoint htpasswd httpd:2 -Bbn dpr-user dpr-pass > /var/auth/dpr/htpasswd
