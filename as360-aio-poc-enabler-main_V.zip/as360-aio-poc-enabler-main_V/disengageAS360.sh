#!/usr/bin/env sh

# Exit on failure
set -e

cd aio

./tearMeDown.sh

./disassembleMe.sh

./cleanMe.sh

cd ..
