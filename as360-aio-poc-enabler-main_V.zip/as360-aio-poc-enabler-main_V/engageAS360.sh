#!/usr/bin/env sh

# Exit on failure
set -e

cd aio

# Engage AIO
./engageAIO.sh

# Engage ASRA
./engageASRA.sh

# Read user input into DOMAIN for ASCP invocation
read -p 'Please enter the designated Domain name (e.g. "appscan.com"): ' DOMAIN

# Engage ASCP
./engageASCP.sh ${DOMAIN}

# Wait for ASCP and ASRA background scripts to end
#wait

#echo "Going to sleep for 2 minutes while waiting for AS360 to warm up..."
#sleep 120

cd ..
